import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import { Provider, useDispatch } from 'react-redux';
import { store, setInteractions, setHcps } from './store';
import { fetchInteractions, fetchHcps } from './api';
import LogInteractionPage from './pages/LogInteractionPage';
import InteractionsListPage from './pages/InteractionsListPage';
import './App.css';

function Layout() {
  const dispatch = useDispatch();

  useEffect(() => {
    fetchInteractions().then(r => dispatch(setInteractions(r.data))).catch(() => {});
    fetchHcps().then(r => dispatch(setHcps(r.data))).catch(() => {});
  }, [dispatch]);

  return (
    <div className="app">
      <header className="header">
        <div className="header-brand">
          <div className="brand-icon">⚕</div>
          <div>
            <div className="brand-name">HCP Connect</div>
            <div className="brand-sub">CRM for Life Sciences</div>
          </div>
        </div>
        <nav className="nav">
          <NavLink to="/" end className={({isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
            📋 Log Interaction
          </NavLink>
          <NavLink to="/history" className={({isActive}) => isActive ? 'nav-link active' : 'nav-link'}>
            📚 History
          </NavLink>
        </nav>
        <div className="header-badge">AI-Powered</div>
      </header>
      <main className="main">
        <Routes>
          <Route path="/" element={<LogInteractionPage />} />
          <Route path="/history" element={<InteractionsListPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Layout />
      </BrowserRouter>
    </Provider>
  );
}
