import { configureStore, createSlice } from '@reduxjs/toolkit';

// ── Interactions slice ────────────────────────────────────────────────────────
const interactionsSlice = createSlice({
  name: 'interactions',
  initialState: { list: [], loading: false, error: null, selected: null },
  reducers: {
    setLoading: (state, action) => { state.loading = action.payload; },
    setInteractions: (state, action) => { state.list = action.payload; state.loading = false; },
    addInteraction: (state, action) => { state.list.unshift(action.payload); },
    updateInteraction: (state, action) => {
      const idx = state.list.findIndex(i => i.id === action.payload.id);
      if (idx !== -1) state.list[idx] = action.payload;
    },
    removeInteraction: (state, action) => {
      state.list = state.list.filter(i => i.id !== action.payload);
    },
    setSelected: (state, action) => { state.selected = action.payload; },
    setError: (state, action) => { state.error = action.payload; state.loading = false; },
  },
});

// ── Chat slice ────────────────────────────────────────────────────────────────
const chatSlice = createSlice({
  name: 'chat',
  initialState: { messages: [], loading: false },
  reducers: {
    addMessage: (state, action) => { state.messages.push(action.payload); },
    setChatLoading: (state, action) => { state.loading = action.payload; },
    clearChat: (state) => { state.messages = []; },
  },
});

// ── HCPs slice ────────────────────────────────────────────────────────────────
const hcpsSlice = createSlice({
  name: 'hcps',
  initialState: { list: [] },
  reducers: {
    setHcps: (state, action) => { state.list = action.payload; },
  },
});

export const { setLoading, setInteractions, addInteraction, updateInteraction, removeInteraction, setSelected, setError } = interactionsSlice.actions;
export const { addMessage, setChatLoading, clearChat } = chatSlice.actions;
export const { setHcps } = hcpsSlice.actions;

export const store = configureStore({
  reducer: {
    interactions: interactionsSlice.reducer,
    chat: chatSlice.reducer,
    hcps: hcpsSlice.reducer,
  },
});
