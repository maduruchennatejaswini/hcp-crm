import axios from 'axios';

const api = axios.create({ baseURL: 'http://localhost:8000' });

export const fetchInteractions = () => api.get('/interactions');
export const fetchHcps = () => api.get('/hcps');
export const createInteraction = (data) => api.post('/interactions', data);
export const updateInteraction = (id, data) => api.put(`/interactions/${id}`, data);
export const deleteInteraction = (id) => api.delete(`/interactions/${id}`);
export const fetchAnalytics = () => api.get('/analytics/summary');
export const sendChatMessage = (message, history) =>
  api.post('/chat', { message, conversation_history: history });

export default api;
