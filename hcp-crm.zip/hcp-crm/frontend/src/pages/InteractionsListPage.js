import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeInteraction, updateInteraction as updateStore } from '../store';
import { deleteInteraction, updateInteraction } from '../api';

function EditModal({ interaction, onClose, onSave }) {
  const [form, setForm] = useState({ ...interaction });
  const [loading, setLoading] = useState(false);

  const handle = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const save = async () => {
    setLoading(true);
    try {
      const res = await updateInteraction(interaction.id, form);
      onSave(res.data);
      onClose();
    } catch (e) {
      alert('Failed to update');
    }
    setLoading(false);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-title">✏️ Edit Interaction #{interaction.id}</div>
        <div className="form-grid">
          <div className="form-group">
            <label className="form-label">HCP Name</label>
            <input className="form-input" name="hcp_name" value={form.hcp_name} onChange={handle} />
          </div>
          <div className="form-group">
            <label className="form-label">Interaction Type</label>
            <select className="form-select" name="interaction_type" value={form.interaction_type} onChange={handle}>
              {['Meeting','Call','Email','Conference','CME Event','Advisory Board','Lunch & Learn'].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-group full">
            <label className="form-label">Topics Discussed</label>
            <textarea className="form-textarea" name="topics_discussed" value={form.topics_discussed || ''} onChange={handle} />
          </div>
          <div className="form-group full">
            <label className="form-label">Outcomes</label>
            <textarea className="form-textarea" name="outcomes" value={form.outcomes || ''} onChange={handle} style={{minHeight:60}} />
          </div>
          <div className="form-group full">
            <label className="form-label">Follow-up Actions</label>
            <textarea className="form-textarea" name="follow_up_actions" value={form.follow_up_actions || ''} onChange={handle} style={{minHeight:60}} />
          </div>
          <div className="form-group full">
            <label className="form-label">Sentiment</label>
            <div className="sentiment-group">
              {['Positive','Neutral','Negative'].map(s => (
                <button key={s} type="button"
                  className={`sentiment-btn ${s.toLowerCase()} ${form.sentiment === s ? 'active' : ''}`}
                  onClick={() => setForm(f => ({...f, sentiment: s}))}>
                  {s === 'Positive' ? '😊' : s === 'Neutral' ? '😐' : '😞'} {s}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="form-actions">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={save} disabled={loading}>
            {loading ? 'Saving...' : '💾 Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function InteractionsListPage() {
  const dispatch = useDispatch();
  const interactions = useSelector(s => s.interactions.list);
  const [search, setSearch] = useState('');
  const [editTarget, setEditTarget] = useState(null);
  const [toast, setToast] = useState(null);

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const filtered = interactions.filter(i =>
    i.hcp_name?.toLowerCase().includes(search.toLowerCase()) ||
    i.interaction_type?.toLowerCase().includes(search.toLowerCase()) ||
    i.topics_discussed?.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this interaction?')) return;
    try {
      await deleteInteraction(id);
      dispatch(removeInteraction(id));
      showToast('Deleted successfully');
    } catch {
      showToast('Delete failed', 'error');
    }
  };

  const handleSave = (updated) => {
    dispatch(updateStore(updated));
    showToast('Updated successfully');
  };

  return (
    <div>
      <div className="list-header">
        <div className="list-title">📚 Interaction History</div>
        <input className="search-box" placeholder="🔍 Search by HCP, type, or topic..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div style={{ marginBottom: 12, color: 'var(--gray-500)', fontSize: 13 }}>
        {filtered.length} interaction{filtered.length !== 1 ? 's' : ''} found
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <div style={{ fontWeight: 600, marginBottom: 8 }}>No interactions yet</div>
          <div>Log your first HCP interaction from the Log Interaction screen.</div>
        </div>
      ) : (
        filtered.map(i => (
          <div key={i.id} className="interaction-card">
            <div className="ic-header">
              <div className="ic-name">{i.hcp_name}</div>
              <span className="ic-type">{i.interaction_type}</span>
            </div>
            <div className="ic-meta">📅 {i.date} at {i.time}{i.attendees ? ` · 👥 ${i.attendees}` : ''}</div>
            {i.topics_discussed && <div className="ic-topics">💬 {i.topics_discussed}</div>}
            {i.outcomes && <div style={{ fontSize: 12, color: 'var(--gray-600)', marginBottom: 6 }}>✅ {i.outcomes}</div>}
            {i.follow_up_actions && <div style={{ fontSize: 12, color: 'var(--gray-600)', marginBottom: 8 }}>🔜 {i.follow_up_actions}</div>}
            <div className="ic-footer">
              <span className={`sentiment-tag ${i.sentiment}`}>
                {i.sentiment === 'Positive' ? '😊' : i.sentiment === 'Negative' ? '😞' : '😐'} {i.sentiment}
              </span>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-ghost" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => setEditTarget(i)}>✏️ Edit</button>
                <button className="btn btn-danger" style={{ padding: '5px 12px', fontSize: 12 }} onClick={() => handleDelete(i.id)}>🗑️ Delete</button>
              </div>
            </div>
          </div>
        ))
      )}

      {editTarget && <EditModal interaction={editTarget} onClose={() => setEditTarget(null)} onSave={handleSave} />}
      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
    </div>
  );
}
