import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addInteraction, addMessage, setChatLoading } from '../store';
import { createInteraction, sendChatMessage } from '../api';

const INTERACTION_TYPES = ['Meeting', 'Call', 'Email', 'Conference', 'CME Event', 'Advisory Board', 'Lunch & Learn'];
const SUGGESTIONS = [
  'Log a meeting with Dr. Sharma about Product X efficacy',
  'Get history for Dr. Mehta',
  'Suggest follow-up for a positive interaction',
  'Analyze sentiment: The doctor seemed very interested and agreed to prescribe',
];

export default function LogInteractionPage() {
  const dispatch = useDispatch();
  const hcps = useSelector(s => s.hcps.list);
  const chatMessages = useSelector(s => s.chat.messages);
  const chatLoading = useSelector(s => s.chat.loading);
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const [toast, setToast] = useState(null);
  const [formLoading, setFormLoading] = useState(false);

  const [form, setForm] = useState({
    hcp_name: '', interaction_type: 'Meeting', date: new Date().toISOString().split('T')[0],
    time: new Date().toTimeString().slice(0,5), attendees: '', topics_discussed: '',
    materials_shared: '', samples_distributed: '', sentiment: 'Neutral', outcomes: '', follow_up_actions: '',
  });

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleForm = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async () => {
    if (!form.hcp_name || !form.topics_discussed) {
      showToast('HCP Name and Topics are required', 'error');
      return;
    }
    setFormLoading(true);
    try {
      const res = await createInteraction(form);
      dispatch(addInteraction(res.data));
      showToast('Interaction logged successfully!');
      setForm(f => ({ ...f, topics_discussed: '', outcomes: '', follow_up_actions: '', attendees: '', materials_shared: '', samples_distributed: '' }));
    } catch (e) {
      showToast('Failed to log interaction', 'error');
    }
    setFormLoading(false);
  };

  const handleChat = async (msg) => {
    const message = msg || chatInput.trim();
    if (!message) return;
    setChatInput('');

    const userMsg = { role: 'user', content: message };
    dispatch(addMessage({ type: 'user', text: message }));
    dispatch(setChatLoading(true));

    const newHistory = [...chatHistory, userMsg];
    try {
      const res = await sendChatMessage(message, chatHistory);
      const { response, tool_calls_made } = res.data;
      dispatch(addMessage({ type: 'assistant', text: response, tools: tool_calls_made }));
      setChatHistory([...newHistory, { role: 'assistant', content: response }]);
    } catch (e) {
      dispatch(addMessage({ type: 'assistant', text: 'Error connecting to AI agent. Make sure the backend is running and GROQ_API_KEY is set.' }));
    }
    dispatch(setChatLoading(false));
  };

  return (
    <div className="page-grid">
      {/* ── Form Panel ── */}
      <div>
        <div className="card">
          <div className="card-title">📋 Log HCP Interaction</div>
          <div className="form-grid">
            <div className="form-group">
              <label className="form-label">HCP Name *</label>
              <input
                className="form-input"
                name="hcp_name"
                value={form.hcp_name}
                onChange={handleForm}
                list="hcp-list"
                placeholder="Search or enter HCP name..."
              />
              <datalist id="hcp-list">
                {hcps.map(h => <option key={h.id} value={h.name}>{h.name} – {h.specialty}</option>)}
              </datalist>
            </div>

            <div className="form-group">
              <label className="form-label">Interaction Type</label>
              <select className="form-select" name="interaction_type" value={form.interaction_type} onChange={handleForm}>
                {INTERACTION_TYPES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Date</label>
              <input className="form-input" type="date" name="date" value={form.date} onChange={handleForm} />
            </div>

            <div className="form-group">
              <label className="form-label">Time</label>
              <input className="form-input" type="time" name="time" value={form.time} onChange={handleForm} />
            </div>

            <div className="form-group full">
              <label className="form-label">Attendees</label>
              <input className="form-input" name="attendees" value={form.attendees} onChange={handleForm} placeholder="Enter names..." />
            </div>

            <div className="form-group full">
              <label className="form-label">Topics Discussed *</label>
              <textarea className="form-textarea" name="topics_discussed" value={form.topics_discussed} onChange={handleForm} placeholder="Key discussion points..." />
            </div>

            <div className="form-group">
              <label className="form-label">Materials Shared</label>
              <input className="form-input" name="materials_shared" value={form.materials_shared} onChange={handleForm} placeholder="Brochures, studies..." />
            </div>

            <div className="form-group">
              <label className="form-label">Samples Distributed</label>
              <input className="form-input" name="samples_distributed" value={form.samples_distributed} onChange={handleForm} placeholder="Drug samples..." />
            </div>

            <div className="form-group full">
              <label className="form-label">Observed HCP Sentiment</label>
              <div className="sentiment-group">
                {['Positive', 'Neutral', 'Negative'].map(s => (
                  <button
                    key={s}
                    type="button"
                    className={`sentiment-btn ${s.toLowerCase()} ${form.sentiment === s ? 'active' : ''}`}
                    onClick={() => setForm(f => ({ ...f, sentiment: s }))}
                  >
                    {s === 'Positive' ? '😊' : s === 'Neutral' ? '😐' : '😞'} {s}
                  </button>
                ))}
              </div>
            </div>

            <div className="form-group full">
              <label className="form-label">Outcomes / Agreements</label>
              <textarea className="form-textarea" name="outcomes" value={form.outcomes} onChange={handleForm} placeholder="Key outcomes or agreements reached..." style={{ minHeight: 64 }} />
            </div>

            <div className="form-group full">
              <label className="form-label">Follow-up Actions</label>
              <textarea className="form-textarea" name="follow_up_actions" value={form.follow_up_actions} onChange={handleForm} placeholder="Next steps and tasks..." style={{ minHeight: 64 }} />
            </div>
          </div>

          <div className="form-actions">
            <button className="btn btn-ghost" onClick={() => setForm(f => ({ ...f, topics_discussed: '', outcomes: '', follow_up_actions: '' }))}>Clear</button>
            <button className="btn btn-primary" onClick={handleSubmit} disabled={formLoading}>
              {formLoading ? '⏳ Saving...' : '💾 Log Interaction'}
            </button>
          </div>
        </div>
      </div>

      {/* ── Chat Panel ── */}
      <div>
        <div className="chat-panel">
          <div className="chat-header">
            🤖 AI Assistant
            <span style={{ marginLeft: 'auto', fontSize: 11, opacity: 0.8 }}>LangGraph • Groq</span>
          </div>

          <div className="chat-suggestions">
            <div className="chat-suggestion-label">Try asking:</div>
            <div className="suggestion-chips">
              {SUGGESTIONS.map((s, i) => (
                <button key={i} className="chip" onClick={() => handleChat(s)}>
                  {s.length > 40 ? s.slice(0, 40) + '…' : s}
                </button>
              ))}
            </div>
          </div>

          <div className="chat-messages">
            {chatMessages.length === 0 && (
              <div className="msg system">
                Describe an interaction or ask for help logging, editing, or analyzing HCP visits.
              </div>
            )}
            {chatMessages.map((m, i) => (
              <div key={i} className={`msg ${m.type}`}>
                {m.text}
                {m.tools && m.tools.length > 0 && (
                  <div>{m.tools.map((t, j) => <span key={j} className="tool-badge">🔧 {t}</span>)}</div>
                )}
              </div>
            ))}
            {chatLoading && <div className="msg system">⏳ AI agent thinking...</div>}
          </div>

          <div className="chat-footer">
            <input
              className="chat-input"
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleChat()}
              placeholder="Describe interaction or ask..."
            />
            <button className="btn btn-primary" onClick={() => handleChat()} disabled={chatLoading || !chatInput.trim()}>
              Send
            </button>
          </div>
        </div>
      </div>

      {toast && <div className={`toast ${toast.type}`}>{toast.msg}</div>}
    </div>
  );
}
