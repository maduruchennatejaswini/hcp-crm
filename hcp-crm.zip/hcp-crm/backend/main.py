from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import sqlite3
import json
from datetime import datetime
from agent import run_agent
import uvicorn

app = FastAPI(title="HCP CRM API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── DB setup ──────────────────────────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect("hcp_crm.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS interactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hcp_name TEXT NOT NULL,
            interaction_type TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            attendees TEXT,
            topics_discussed TEXT,
            materials_shared TEXT,
            samples_distributed TEXT,
            sentiment TEXT DEFAULT 'Neutral',
            outcomes TEXT,
            follow_up_actions TEXT,
            ai_summary TEXT,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS hcps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            specialty TEXT,
            institution TEXT,
            email TEXT,
            phone TEXT
        )
    """)
    # Seed some HCPs
    existing = conn.execute("SELECT COUNT(*) FROM hcps").fetchone()[0]
    if existing == 0:
        hcps = [
            ("Dr. Anjali Sharma", "Oncology", "Apollo Hospital", "anjali@apollo.com", "9876543210"),
            ("Dr. Rajiv Mehta", "Cardiology", "Fortis Healthcare", "rajiv@fortis.com", "9876543211"),
            ("Dr. Priya Nair", "Neurology", "Manipal Hospital", "priya@manipal.com", "9876543212"),
            ("Dr. Suresh Kumar", "Endocrinology", "NIMHANS", "suresh@nimhans.com", "9876543213"),
            ("Dr. Kavya Reddy", "Pulmonology", "Narayana Health", "kavya@narayana.com", "9876543214"),
        ]
        conn.executemany("INSERT INTO hcps (name, specialty, institution, email, phone) VALUES (?,?,?,?,?)", hcps)
    conn.commit()
    conn.close()

init_db()

# ── Schemas ───────────────────────────────────────────────────────────────────
class InteractionCreate(BaseModel):
    hcp_name: str
    interaction_type: str
    date: str
    time: str
    attendees: Optional[str] = ""
    topics_discussed: Optional[str] = ""
    materials_shared: Optional[str] = ""
    samples_distributed: Optional[str] = ""
    sentiment: Optional[str] = "Neutral"
    outcomes: Optional[str] = ""
    follow_up_actions: Optional[str] = ""

class InteractionUpdate(BaseModel):
    hcp_name: Optional[str] = None
    interaction_type: Optional[str] = None
    date: Optional[str] = None
    time: Optional[str] = None
    attendees: Optional[str] = None
    topics_discussed: Optional[str] = None
    materials_shared: Optional[str] = None
    samples_distributed: Optional[str] = None
    sentiment: Optional[str] = None
    outcomes: Optional[str] = None
    follow_up_actions: Optional[str] = None

class ChatMessage(BaseModel):
    message: str
    conversation_history: Optional[List[dict]] = []

# ── Routes ────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"status": "HCP CRM API running"}

@app.get("/hcps")
def list_hcps():
    conn = get_db()
    rows = conn.execute("SELECT * FROM hcps").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/interactions")
def list_interactions():
    conn = get_db()
    rows = conn.execute("SELECT * FROM interactions ORDER BY created_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/interactions/{interaction_id}")
def get_interaction(interaction_id: int):
    conn = get_db()
    row = conn.execute("SELECT * FROM interactions WHERE id=?", (interaction_id,)).fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="Interaction not found")
    return dict(row)

@app.post("/interactions")
def create_interaction(data: InteractionCreate):
    conn = get_db()
    cursor = conn.execute("""
        INSERT INTO interactions
        (hcp_name, interaction_type, date, time, attendees, topics_discussed,
         materials_shared, samples_distributed, sentiment, outcomes, follow_up_actions)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (data.hcp_name, data.interaction_type, data.date, data.time,
          data.attendees, data.topics_discussed, data.materials_shared,
          data.samples_distributed, data.sentiment, data.outcomes, data.follow_up_actions))
    conn.commit()
    new_id = cursor.lastrowid
    row = conn.execute("SELECT * FROM interactions WHERE id=?", (new_id,)).fetchone()
    conn.close()
    return dict(row)

@app.put("/interactions/{interaction_id}")
def update_interaction(interaction_id: int, data: InteractionUpdate):
    conn = get_db()
    row = conn.execute("SELECT * FROM interactions WHERE id=?", (interaction_id,)).fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Not found")
    current = dict(row)
    updates = {k: v for k, v in data.dict().items() if v is not None}
    current.update(updates)
    conn.execute("""
        UPDATE interactions SET
        hcp_name=?, interaction_type=?, date=?, time=?, attendees=?,
        topics_discussed=?, materials_shared=?, samples_distributed=?,
        sentiment=?, outcomes=?, follow_up_actions=?
        WHERE id=?
    """, (current['hcp_name'], current['interaction_type'], current['date'],
          current['time'], current['attendees'], current['topics_discussed'],
          current['materials_shared'], current['samples_distributed'],
          current['sentiment'], current['outcomes'], current['follow_up_actions'],
          interaction_id))
    conn.commit()
    updated = conn.execute("SELECT * FROM interactions WHERE id=?", (interaction_id,)).fetchone()
    conn.close()
    return dict(updated)

@app.delete("/interactions/{interaction_id}")
def delete_interaction(interaction_id: int):
    conn = get_db()
    conn.execute("DELETE FROM interactions WHERE id=?", (interaction_id,))
    conn.commit()
    conn.close()
    return {"message": "Deleted successfully"}

@app.post("/chat")
async def chat(body: ChatMessage):
    result = await run_agent(body.message, body.conversation_history)
    return result

@app.get("/analytics/summary")
def analytics_summary():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM interactions").fetchone()[0]
    by_type = conn.execute(
        "SELECT interaction_type, COUNT(*) as count FROM interactions GROUP BY interaction_type"
    ).fetchall()
    by_sentiment = conn.execute(
        "SELECT sentiment, COUNT(*) as count FROM interactions GROUP BY sentiment"
    ).fetchall()
    recent = conn.execute(
        "SELECT hcp_name, interaction_type, date FROM interactions ORDER BY created_at DESC LIMIT 5"
    ).fetchall()
    conn.close()
    return {
        "total_interactions": total,
        "by_type": [dict(r) for r in by_type],
        "by_sentiment": [dict(r) for r in by_sentiment],
        "recent": [dict(r) for r in recent]
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
