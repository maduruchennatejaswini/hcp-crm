"""
LangGraph AI Agent for HCP CRM
Tools:
  1. log_interaction      - capture and summarize an HCP visit
  2. edit_interaction     - modify an existing logged interaction
  3. get_hcp_history      - retrieve past interactions for an HCP
  4. suggest_follow_up    - AI-powered next-best-action suggestions
  5. analyze_sentiment    - classify HCP sentiment from free text
"""

import os
import json
import sqlite3
from datetime import datetime
from typing import Any, Optional

from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_core.tools import tool
from langchain_groq import ChatGroq

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "your_groq_api_key_here")

def db():
    conn = sqlite3.connect("hcp_crm.db")
    conn.row_factory = sqlite3.Row
    return conn


@tool
def log_interaction(
    hcp_name: str,
    interaction_type: str,
    topics_discussed: str,
    outcomes: str = "",
    sentiment: str = "Neutral",
    attendees: str = "",
    materials_shared: str = "",
    samples_distributed: str = "",
    follow_up_actions: str = "",
) -> str:
    """
    Log a new HCP interaction into the CRM database.
    Automatically generates an AI summary using the provided details.

    Args:
        hcp_name: Full name of the Healthcare Professional
        interaction_type: Type (Meeting, Call, Email, Conference, etc.)
        topics_discussed: Key discussion points
        outcomes: Agreements or outcomes from the interaction
        sentiment: Observed HCP sentiment (Positive/Neutral/Negative)
        attendees: Names of attendees
        materials_shared: Literature or brochures shared
        samples_distributed: Drug samples given
        follow_up_actions: Planned next steps
    """
    now = datetime.now()
    date_str = now.strftime("%Y-%m-%d")
    time_str = now.strftime("%H:%M")

    summary = (
        f"Interaction with {hcp_name} ({interaction_type}) on {date_str}. "
        f"Topics: {topics_discussed}. "
        f"Outcomes: {outcomes or 'None recorded'}. "
        f"Sentiment: {sentiment}. "
        f"Follow-up: {follow_up_actions or 'None planned'}."
    )

    conn = db()
    cursor = conn.execute("""
        INSERT INTO interactions
        (hcp_name, interaction_type, date, time, attendees, topics_discussed,
         materials_shared, samples_distributed, sentiment, outcomes,
         follow_up_actions, ai_summary)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
    """, (hcp_name, interaction_type, date_str, time_str, attendees,
          topics_discussed, materials_shared, samples_distributed,
          sentiment, outcomes, follow_up_actions, summary))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()

    return json.dumps({
        "success": True,
        "message": f"Interaction logged successfully with ID {new_id}",
        "interaction_id": new_id,
        "summary": summary
    })


@tool
def edit_interaction(
    interaction_id: int,
    field: str,
    new_value: str,
) -> str:
    """
    Edit a specific field in an already-logged HCP interaction.

    Args:
        interaction_id: The numeric ID of the interaction to edit
        field: Field name to update (e.g. topics_discussed, sentiment, outcomes, follow_up_actions)
        new_value: The new value to set for the field
    """
    allowed_fields = {
        "hcp_name", "interaction_type", "date", "time", "attendees",
        "topics_discussed", "materials_shared", "samples_distributed",
        "sentiment", "outcomes", "follow_up_actions"
    }
    if field not in allowed_fields:
        return json.dumps({"success": False, "error": f"Field '{field}' cannot be edited."})

    conn = db()
    row = conn.execute("SELECT * FROM interactions WHERE id=?", (interaction_id,)).fetchone()
    if not row:
        conn.close()
        return json.dumps({"success": False, "error": f"No interaction found with ID {interaction_id}"})

    conn.execute(f"UPDATE interactions SET {field}=? WHERE id=?", (new_value, interaction_id))
    conn.commit()
    updated = conn.execute("SELECT * FROM interactions WHERE id=?", (interaction_id,)).fetchone()
    conn.close()

    return json.dumps({
        "success": True,
        "message": f"Updated '{field}' for interaction {interaction_id}",
        "updated_interaction": dict(updated)
    })


@tool
def get_hcp_history(hcp_name: str, limit: int = 5) -> str:
    """
    Retrieve the interaction history for a specific Healthcare Professional.

    Args:
        hcp_name: Name of the HCP to look up
        limit: Maximum number of past interactions to return (default 5)
    """
    conn = db()
    rows = conn.execute("""
        SELECT id, interaction_type, date, topics_discussed, sentiment, outcomes, follow_up_actions
        FROM interactions
        WHERE hcp_name LIKE ?
        ORDER BY date DESC, time DESC
        LIMIT ?
    """, (f"%{hcp_name}%", limit)).fetchall()
    conn.close()

    if not rows:
        return json.dumps({"success": True, "message": f"No interactions found for '{hcp_name}'", "interactions": []})

    return json.dumps({
        "success": True,
        "hcp_name": hcp_name,
        "total_found": len(rows),
        "interactions": [dict(r) for r in rows]
    })


@tool
def suggest_follow_up(hcp_name: str, last_topics: str, sentiment: str = "Neutral") -> str:
    """
    Generate AI-powered follow-up action suggestions for a sales rep after an HCP interaction.

    Args:
        hcp_name: Name of the HCP
        last_topics: Topics discussed in the last interaction
        sentiment: HCP sentiment observed (Positive/Neutral/Negative)
    """
    suggestions = []
    sentiment_lower = sentiment.lower()
    topics_lower = last_topics.lower()

    if sentiment_lower == "positive":
        suggestions.append(f"Schedule a follow-up meeting with {hcp_name} within 2 weeks to maintain momentum")
        suggestions.append("Send a thank-you email with a clinical study supporting discussed products")
    elif sentiment_lower == "negative":
        suggestions.append(f"Allow a cool-off period of 3-4 weeks before re-engaging {hcp_name}")
        suggestions.append("Consult your medical affairs team to address any clinical concerns raised")
    else:
        suggestions.append(f"Send educational materials to {hcp_name} to build product awareness")
        suggestions.append("Invite to an upcoming KOL webinar or advisory board event")

    if "sample" in topics_lower or "trial" in topics_lower:
        suggestions.append("Follow up on sample usage feedback after 4 weeks")
    if "data" in topics_lower or "efficacy" in topics_lower:
        suggestions.append("Share the latest clinical trial data and real-world evidence PDF")
    if "competitor" in topics_lower:
        suggestions.append("Arrange a competitive intelligence briefing with your medical team")

    suggestions.append("Log this interaction in the CRM within 24 hours for compliance")

    return json.dumps({
        "success": True,
        "hcp_name": hcp_name,
        "sentiment": sentiment,
        "suggested_follow_ups": suggestions
    })


@tool
def analyze_sentiment(text: str, hcp_name: str = "") -> str:
    """
    Analyze the sentiment expressed in free-form text about an HCP interaction.
    Returns Positive, Neutral, or Negative with explanation.

    Args:
        text: Free-form description of the HCP interaction or HCP remarks
        hcp_name: Optional name of the HCP for context
    """
    text_lower = text.lower()

    positive_signals = [
        "interested", "enthusiastic", "agreed", "positive", "impressed",
        "willing", "excited", "supportive", "prescribe", "recommend",
        "happy", "great", "excellent", "good", "open to"
    ]
    negative_signals = [
        "refused", "not interested", "skeptical", "concerned", "complaint",
        "unhappy", "rejected", "busy", "negative", "won't", "cannot",
        "dissatisfied", "difficult", "no time", "competitor"
    ]

    pos_count = sum(1 for w in positive_signals if w in text_lower)
    neg_count = sum(1 for w in negative_signals if w in text_lower)

    if pos_count > neg_count:
        sentiment = "Positive"
        explanation = f"Detected {pos_count} positive signal(s) suggesting receptiveness."
    elif neg_count > pos_count:
        sentiment = "Negative"
        explanation = f"Detected {neg_count} negative signal(s) indicating resistance or dissatisfaction."
    else:
        sentiment = "Neutral"
        explanation = "No strong positive or negative signals. Interaction appears neutral."

    return json.dumps({
        "success": True,
        "hcp_name": hcp_name,
        "sentiment": sentiment,
        "explanation": explanation,
        "positive_signals_found": pos_count,
        "negative_signals_found": neg_count
    })


tools = [log_interaction, edit_interaction, get_hcp_history, suggest_follow_up, analyze_sentiment]

SYSTEM_PROMPT = """You are an intelligent AI assistant embedded in a pharmaceutical CRM system,
helping field sales representatives manage their Healthcare Professional (HCP) interactions.

You have access to these tools:
1. log_interaction - Log a new HCP interaction with full details
2. edit_interaction - Edit an existing logged interaction
3. get_hcp_history - Retrieve past interaction history for an HCP
4. suggest_follow_up - Get AI-powered follow-up action suggestions
5. analyze_sentiment - Analyze the sentiment from free-form text

Always be professional and focused on helping the sales rep be productive.
When logging, extract key details (HCP name, type, topics, outcomes) from the user message.
Summarize what you did clearly after completing each task."""


async def run_agent(user_message: str, conversation_history: list = []) -> dict:
    try:
        llm = ChatGroq(
            model="gemma2-9b-it",
            api_key=GROQ_API_KEY,
            temperature=0.2,
        )
        agent = create_react_agent(llm, tools)

        messages = [SystemMessage(content=SYSTEM_PROMPT)]
        for msg in conversation_history[-6:]:
            if msg.get("role") == "user":
                messages.append(HumanMessage(content=msg["content"]))
            elif msg.get("role") == "assistant":
                messages.append(AIMessage(content=msg["content"]))
        messages.append(HumanMessage(content=user_message))

        result = await agent.ainvoke({"messages": messages})

        ai_messages = [m for m in result["messages"] if isinstance(m, AIMessage)]
        response_text = ai_messages[-1].content if ai_messages else "Could not process request."

        tool_calls_made = []
        for m in result["messages"]:
            if hasattr(m, 'tool_calls') and m.tool_calls:
                for tc in m.tool_calls:
                    tool_calls_made.append(tc.get("name", ""))

        return {
            "response": response_text,
            "tool_calls_made": tool_calls_made,
            "success": True
        }

    except Exception as e:
        return {
            "response": f"Error: {str(e)}. Check your Groq API key.",
            "tool_calls_made": [],
            "success": False,
            "error": str(e)
        }
